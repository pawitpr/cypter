# Jaycrypt

A simple JavaScript string encoder, designed to be easily decodeable if the **encryption order** and **Caesar shifter** is known.

![image](https://user-images.githubusercontent.com/69168154/226168412-262f5b65-c4d2-4917-ae0a-34829349101f.png)

## Usage
1. Clone the repository.
2. Install [NodeJS](https://nodejs.org/en/download) (if you haven't already).
3. Run `npm i`
4. Run `node .`
5. Follow the instructions ;)

## Inspiration
- [https://github.com/KuroLabs/stegcloak](stegcloak)

### Made in 1 hour, lol